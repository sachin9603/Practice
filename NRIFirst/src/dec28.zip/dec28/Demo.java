package dec28;

public class Demo {
	
// file  --new - new java project  ---> into project 
// --->> src (right click) ----> new --- >
//then package create ---- >>then package par click (right click )
// ---> new --> class  ---> 
	
	// your class is ready  
	
	// you can't use keyword (that word which are already define in language)
	// it should not start with number 
	// it should  not start with special character or you in between  als
	// exception($ ,_ )
	
	// camel case ---- >>> nristudent
	// pascal case  ---- >>> NriStudent 
	
	// you can't space in between 
	
	
	
	   //int  #studentAge = 18 ;
	
	//case Case CAS
	// data type 
	
	int  a  = 12 ;
	byte  c  = 32 ;
	short  A  = 3343 ;
	long  aa = 323234 ;
	
	float pizzaPrice = 89.4f;
	double pp  = 23.123434 ;
	
	boolean  b  = false ;
	
	String s = "sachin" ;

	
	
	 // is java is fully object oriented language 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	   
	   
	
	
	
	
 
	
	
	
	
	 
}
