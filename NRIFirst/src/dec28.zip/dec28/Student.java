package dec28;

public class Student {
 //davadf
//	 sari jaankari aapko likhna hoti 
//	d
//	advadfvea
//	advfadfvad
//	vasdvadf
	public static void main(String [] args )
	
	{
		String sss  = "sdasdfs" ;
		
	System.out.println("Hello world ") ;
		System.out.print("ram") ;
		System.out.print("rohan") ;
		System.out.println ("sita") ;
		
		// there are 8 primitive data type 
		
		int sssss = 3434 ;
	 // 	char  
		char dd = 65 ; 
		
		System.out.println(dd);
// int , char , short , boolean , long , byte , float  , double 
		
		int sp  = 22 ;
		
		
		
		
		
}
}


