package Tender.Usecase;

public class name {
public static void main(String[] args) {
	System.out.println("sachin parmar");
}
}
