package Tender.Usecase;

import java.util.List;

import Tender.Exception.VenderException;
import Tender.Model.Vender;
import Tender.dao.adminDao;
import Tender.daoImpl.adminDaoImpl;

public class getAllVender {

	public static void main(String[] args) {
		
		adminDao dao = new Tender.daoImpl.adminDaoImpl();
	try {
		List <Vender> venders =	dao.getAllVender();
		
		for (Vender vender : venders) {
			System.out.println(vender);
		}
	} catch (VenderException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
		
		
	}

}
