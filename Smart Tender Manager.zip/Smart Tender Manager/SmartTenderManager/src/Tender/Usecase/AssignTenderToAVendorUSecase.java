package Tender.Usecase;

public class AssignTenderToAVendorUSecase {

	public static void main(String[] args) {
		

	}

}
