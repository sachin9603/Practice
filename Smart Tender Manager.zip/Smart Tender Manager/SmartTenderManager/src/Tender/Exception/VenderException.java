package Tender.Exception;

public class VenderException extends Exception {
	
	public VenderException() {
		// TODO Auto-generated constructor stub
	}
	public VenderException(String message) {
		super(message);
	}

}
