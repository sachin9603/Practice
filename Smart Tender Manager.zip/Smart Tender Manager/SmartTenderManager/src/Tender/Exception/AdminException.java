package Tender.Exception;

public class AdminException extends Exception {
	
	public AdminException() {
		// TODO Auto-generated constructor stub
	}
	public AdminException(String message) {
		super(message);
	}

}
