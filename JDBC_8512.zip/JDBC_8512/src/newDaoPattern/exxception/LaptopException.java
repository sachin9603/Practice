package newDaoPattern.exxception;

public class LaptopException  extends Exception {

	public LaptopException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LaptopException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
	
	

}
