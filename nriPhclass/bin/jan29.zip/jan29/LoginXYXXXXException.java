package jan29;

public class LoginXYXXXXException  extends Exception{

	public LoginXYXXXXException() {
		
	}

	public LoginXYXXXXException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
