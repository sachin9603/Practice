/**
 * 
 */
/**
 * 
 */
module NRI_JDBC2 {
	requires java.sql;
	requires mysql.connector.j;
}