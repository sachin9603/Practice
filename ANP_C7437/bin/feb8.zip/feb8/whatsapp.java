package feb8;

public abstract class whatsapp {
	
	
	// abs class mai aap abstract method 
	
	public  abstract void sendMessage() ;

	
	// concrete method
	public void icon() {
		System.out.println("hara color ");
	}
	
}
