package feb8;

public class whatsimpl extends whatsapp {

	@Override
	public void sendMessage() {
		// TODO Auto-generated method stub
		System.out.println("what s message has been sent ");
	}

}
