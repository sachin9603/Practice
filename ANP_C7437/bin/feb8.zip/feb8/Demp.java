package feb8;

public class Demp {
public static void main(String[] args) {
	
	whatsapp  ttt  = new whatsimpl() ;
	ttt.icon();
	
	ttt.sendMessage();
	
}
}
