package feb7;

public class Fullstack extends Employee
{
	
	@Override
	public int salary() {
		
		///  1000
		
		return 190000 ;
		
	}

}
