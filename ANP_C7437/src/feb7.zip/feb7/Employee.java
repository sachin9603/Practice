package feb7;

public class Employee {
	
	int id   ;
	
	String name  ;
	
	
	
	public int salary() {
		
		// suppose 100 line 
		
		return 70000 ;
		
	}

}
