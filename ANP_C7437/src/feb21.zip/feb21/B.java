package feb21;

public class B implements Runnable  {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		String name  = Thread.currentThread().getName() ;
		
		for (int i= 2000 ; i<2010 ; i++) {
			System.out.println(i +"----->"+ name);
		}
	}
	
	// do tareeke hai multi thread ko execute karne k  
	// extends Tread class
	// implements runnable interface
	
	

}
