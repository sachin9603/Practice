package feb21;

public class Mutilthread extends Thread {
	// kya kare ki ek or thread 
    public void run() {
    	String name  = 	Thread.currentThread().getName() ;
    for(int i =250 ;i<=500; i++) {
    		System.out.println(i +"second thread "+name);
    	}
    }
	public static void main(String[] args) {
		
	String name  = 	Thread.currentThread().getName() ;
	
	Mutilthread t1  = new Mutilthread () ;
	
	// runnable
	B t2  = new B() ;
	Thread thread2   = new Thread(t2) ;
	
	// extends thread class
	A a  = new A() ;
	a.start();
	
	//t1.run();// it will as single thread 
	thread2.start();
	t1.start() ;// second thread 
	System.out.println(name);
	for(int i =0 ;i<250; i++) {
		System.out.println(i + "main thread ");
	}
}

}
