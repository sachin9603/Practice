package feb21;

public class A extends Thread  {
	@Override
	public void run() {
		// TODO Auto-generated method stub
		String name  = Thread.currentThread().getName() ;
		
		for (int i= 5000 ; i<5010 ; i++) {
			System.out.println(i +"----->"+ name);
		}
	}
	
}
