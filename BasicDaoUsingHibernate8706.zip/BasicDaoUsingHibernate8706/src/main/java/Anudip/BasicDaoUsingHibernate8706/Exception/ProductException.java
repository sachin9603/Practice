package Anudip.BasicDaoUsingHibernate8706.Exception;

public class ProductException extends RuntimeException {

	public ProductException() {
	
	}

	public ProductException(String message) {
	
	}
	
	

}
