package jan9;

import java.util.ArrayList;
import java.util.Collections;

public class StudentTest {

	public static void main(String[] args) {
		
//		ArrayList<Student>  arr = new ArrayList<Student>() ;
//		
//		arr.add(new Student(1, "Sachin" , 500)) ;
//		arr.add(new Student(2, "Rahul" , 420)) ;
//
//		arr.add(new Student(3, "Ravi" , 450)) ;
//
//		arr.add(new Student(4, "Vishal" , 470)) ;
//		
//		
//		Collections.sort(arr);
//		System.out.println(arr);
//
//		
		
ArrayList<Student2>  arr2 = new ArrayList<Student2>() ;
		
		arr2.add(new Student2(1, "Riya" , 500)) ;
		arr2.add(new Student2(2, "Priya" , 420)) ;

		arr2.add(new Student2(3, "Siya" , 450)) ;

		arr2.add(new Student2(4, "Kiya" , 470)) ;
		
		Collections.sort(arr2, new NumberComparator());
		System.out.println(arr2);

		
		
	}
}
