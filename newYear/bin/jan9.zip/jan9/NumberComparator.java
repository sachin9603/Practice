package jan9;

import java.util.Comparator;

public class NumberComparator implements Comparator<Student2> {

	@Override
	public int compare(Student2 o1, Student2 o2) {
		// TODO Auto-generated method stub
		
		if (o1.studentMarks == o2.studentMarks) {
			return 0 ;
		} else if (o1.studentMarks > o2.studentMarks) {
			return  1 ;
		}else {
			return -1  ;
		}
		//return o1.studentMarks - o2.studentMarks;
	}

	
	
}
