package jan8;

public class Student {

}
