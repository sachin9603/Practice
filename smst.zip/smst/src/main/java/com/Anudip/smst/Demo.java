package com.Anudip.smst;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.Anudip.smst.model.smst_;

public class Demo {
	
	public static void main(String[] args) {
		
		EntityManagerFactory emf  = Persistence.createEntityManagerFactory("studentUnit");
		
		EntityManager em = emf.createEntityManager() ;
		
		smst_ student = new smst_("pramn" , "indore" , "23232_2323");
		
		em.getTransaction().begin();  
		
		em.persist(student);
		
		em.getTransaction().commit(); 
		em.close();
		
		
		
	}

}
