package cons;

public class StudentTest {

	
	public static void main(String[] args) {
		Student s  = new Student();//is point time par 
		//default cons co call kiya hai 
		
		Student s1  = new Student(121 , "Ragav" ) ;
		
		System.out.println(s1.studentId);
		
		
		
	}
}
