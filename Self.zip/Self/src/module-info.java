/**
 * 
 */
/**
 * 
 */
module Self {
	requires java.sql;
}