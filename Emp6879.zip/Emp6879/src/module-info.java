/**
 * 
 */
/**
 * 
 */
module Emp6879 {
	requires java.sql;
}