package Emp.Uitlity;

public class queryUtil {
	
	public static String register() {
		
		return  "insert into Employee value(?,?,?,?)" ;
		
	}

}
