/**
 * 
 */
/**
 * 
 */
module JDBC_First {
	requires java.sql;
	requires mysql.connector.j;
}