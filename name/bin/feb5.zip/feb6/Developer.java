package feb6;

public class Developer implements Employee {

	@Override
	public int salary() {
		// TODO Auto-generated method stub
		return 80000;
	}

}
