package feb6;

public class mehngi2 {

	
	// eager way of creating a sigleton obj   
	
	private static mehngi2 mgggg2  = new mehngi2() ;
	
	public static mehngi2 getObjOFMenhgi2(){
		
		return mgggg2  ;
		
		
	}
	
	private mehngi2() {
		
	}
	
	
	
}
