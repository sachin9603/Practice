package feb6;

public interface Employee {
	
	
	public int salary()  ;
	

}
