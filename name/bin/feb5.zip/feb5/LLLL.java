package feb5;

public interface LLLL {

	
	public  int sum (int a , int b) ;
	
}
