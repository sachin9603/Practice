package feb5;

public class FunctionImpl  implements FunctionFucction{

	@Override
	public int squareOF(int a) {
		// TODO Auto-generated method stub
		return a*a *2;
	}

}
