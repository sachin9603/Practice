package feb5;

@FunctionalInterface
public interface P {
	
	
	public void sayHello() ;
	
	// creats a simple class and implement this class 
	
	// agar 5 tarike se implement karna hai toh kaafi hactic process ho jayega 
	// anonyamous class for implementind interface 
	// lamda Expression 

}
