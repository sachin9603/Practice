package feb5;

public class Demo {

	
	public static void main(String[] args) {
		
		
		LLLL  bb  = (  a ,  b) -> a +b ;
			
		 ;
		
		System.out.println(bb.sum(2,4));
		
	}
}
