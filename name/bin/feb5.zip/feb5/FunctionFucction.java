package feb5;

//@FunctionalInterface 
public interface FunctionFucction {
	
	/// is point of time tak this is function interface 
	// interface ki saari method by default abs hoti hai 
	
	public int  squareOF(int a ) ;
	//public void nameOSt(int a ) ;
	
	// consumer matlbki ek argument lega or return mai void 
	
	//public void nameOSt() ;
	
	// i have make a impl class  and i have to make object of that classs bcz  bhai hum 
	// kabhi bhi interface ka obj nahi bnansaktr 
	
	
	
	// 2 Anonymous class 
	
//	
//	default void say() {
//		
//	}
//	
//	
//static void sayhi() {
//		
//	}
	
	

}
