package feb5;

public class FunctionImpl2  implements FunctionFucction{

	@Override
	public int squareOF(int a) {
		// TODO Auto-generated method stub
		return a*a;
	}

}
