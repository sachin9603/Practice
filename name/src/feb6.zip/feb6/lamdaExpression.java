package feb6;

public class lamdaExpression {
	
	// 

}
