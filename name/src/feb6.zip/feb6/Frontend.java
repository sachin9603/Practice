package feb6;

public class Frontend implements Employee {

	@Override
	public int salary() {
		// TODO Auto-generated method stub
		return 50000;
	}

}
