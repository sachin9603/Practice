package nov6;

public class HybridEngine implements Engine  {

	@Override
	public void typeOFEngine() {
		// TODO Auto-generated method stub
		System.out.println("type of Engine is hybrid  ");

		
	}
	

}
