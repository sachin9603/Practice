package nov6;

public class DesielEngine  implements Engine {

	@Override
	public void typeOFEngine() {
		// TODO Auto-generated method stub
		System.out.println("type of Engine is Desiel ");
		
	}
	
	

}
