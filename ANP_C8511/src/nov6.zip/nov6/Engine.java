package nov6;

public interface Engine {
	
	public void typeOFEngine() ;
	

}
