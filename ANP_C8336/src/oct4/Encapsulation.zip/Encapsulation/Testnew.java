package oct4.Encapsulation;

public class Testnew {
	
	
	public static void main(String[] args) {
		
		Address add  = new Address(89 , "Munnar " , "Kerala") ;
		
		Student s  = new Student() ;
		s.setAddress(add);
		
		s.setAdhar("7862836343");
		
		s.setName("Richard Jhonson");
		
		
		System.out.println(add.hashCode());
		add.setCity("allapay");
		
		
		System.out.println(add.hashCode());
		System.out.println(s);
		
		
		
	}

}
