package com.example.com.onitoAssignment.Exception;

public class movieException extends Exception{
    public movieException() {
    }

    public movieException(String message) {
        super(message);
    }
}
