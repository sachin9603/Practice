package com.example.com.onitoAssignment.Model;

public interface MovieDtoInterface {
    String getTconst()  ;
  String getPrimarytitle()  ;
     int getRuntimeminutes()  ;
     String getGenres() ;
}
