package com.example.com.onitoAssignment.Model;

public interface Top_rated_movieInterface {


 String getTconst();
   String getPrimarytitle() ;
   String getGenre() ;
     Double getAveragerating() ;
}
