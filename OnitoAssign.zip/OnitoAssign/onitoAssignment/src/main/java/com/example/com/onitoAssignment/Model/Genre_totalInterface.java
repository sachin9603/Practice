package com.example.com.onitoAssignment.Model;

public interface Genre_totalInterface {

    String getGenre()  ;

     String getPrimarytitle ();

       Integer  getNumvotes() ;
}
