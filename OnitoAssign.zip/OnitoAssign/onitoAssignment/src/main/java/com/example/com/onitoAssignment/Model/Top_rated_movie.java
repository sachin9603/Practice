package com.example.com.onitoAssignment.Model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Top_rated_movie {

    private String tconst ;
    private String primarytitle ;
    private String genre ;
    private Double averagerating  ;


}
