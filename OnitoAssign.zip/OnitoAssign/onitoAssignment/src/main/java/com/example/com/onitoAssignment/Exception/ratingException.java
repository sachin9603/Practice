package com.example.com.onitoAssignment.Exception;

public class ratingException extends  Exception {
    public ratingException() {
    }

    public ratingException(String message) {
        super(message);
    }
}
