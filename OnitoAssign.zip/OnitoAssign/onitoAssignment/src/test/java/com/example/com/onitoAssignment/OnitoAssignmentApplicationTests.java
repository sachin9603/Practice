package com.example.com.onitoAssignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnitoAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
