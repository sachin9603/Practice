package studentManagementSystem.useCase;

public class Main {
	
	
	public static void main(String[] args) {
		new StudentAllOperation().allOps(); 
		
		// all ops  ---- serviceimpl  ---- > dao
	}

}
