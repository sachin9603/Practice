package src.Jdbcc;

public class Baisc2 {

	public static void main(String[] args) {
		System.out.println("sachin");
	}
}
