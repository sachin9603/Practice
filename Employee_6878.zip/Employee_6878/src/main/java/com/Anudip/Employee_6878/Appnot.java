package com.Anudip.Employee_6878;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * Hello world!
 *
 */
public class Appnot 
{
    public static void main( String[] args )
    {
      
    	EntityManagerFactory emf =   Persistence.createEntityManagerFactory("employeeunit");
    	EntityManager em  = emf.createEntityManager() ;
    	
    	em.getTransaction().begin();
    	
    	Department d  = new Department(23  , "cs") ;
    	
    	Employee e  = new Employee(12  , "Raju") ;
    	e.setDep(d);
    	Car c1 = new Car(12 , "maruti" ) ;
    	c1.setEmpId(12);
    	Car c2 = new Car(123 , "wagonar") ;
    	c2.setEmpId(12);
    	
    	
    	List<Car>  cars  = new ArrayList<>() ;
    	cars.add(c1) ;
    	cars.add(c2) ;
    	
    	
    	
    	e.setCars(cars);
    	
    	
    	Employee e2  = new Employee(122  , "Rohan") ;
    	e2.setDep(d);
List<Car>  carss  = new ArrayList<>() ;
Car r3  = new Car(102 , "audi" ) ;
r3.setEmpId(122); 
Car w3  = new Car(1992 , "bmw" ) ;
w3.setEmpId(122); 
    	carss.add(r3) ;
    	carss.add(w3) ;
    	
    	e2.setCars(carss);
 
    	
//    	
//    	
    	
    	
    	em.persist(e);
    	em.persist(e2);
    	
    	
    	em.getTransaction().commit();
    	em.clear();
    	
    	
    }
}
