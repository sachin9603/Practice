package jul2;
// p is a Employee 
public class Programmer extends Employee{
	
	
	@Override
	public String toString() {
		return "Programmer [bonous=" + bonous + ", getName()=" + getName() + ", getId()=" + getId() + ", getSalary()="
				+ getSalary() + "]";
	}

	int bonous  ;
	
	
	
	
	

}
