package jul2;

public class Cat extends Animal {
	
	void meow() {
		System.out.println(" meow meow ......  ");
	}

}
