package jul2;

public class LivingBeings {
	
	void Respiration(){
		
		System.out.println(" a metabolic process that occurs in all organisms.  ");
		
	}

}
