package jul2;

public class Guard {
	
	int overShiftHoursPayment ;
	

}
