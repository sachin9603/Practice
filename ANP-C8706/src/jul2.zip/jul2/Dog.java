package jul2;

public class Dog  extends Animal{
	
	
 void bark() {
	 System.out.println("bow bow ....");
 }

}
