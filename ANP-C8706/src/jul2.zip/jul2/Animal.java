package jul2;

public class Animal extends LivingBeings  {
	
	void eat() {
	System.out.println(" eating something....... ");	
	}

}
