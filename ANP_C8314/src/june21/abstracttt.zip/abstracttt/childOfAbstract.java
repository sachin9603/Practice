package june21.abstracttt;

public class childOfAbstract extends DemoAbstract {

	@Override
	public void saveCutomerDetails() {
		// TODO Auto-generated method stub
		
		System.out.println("yes in this class details are"
				+ " getting processed and  save ");
		
	}

	@Override
	public void takeLoan() {
		// TODO Auto-generated method stub\
		System.out.println("first check customer civil score ");
		
	}
	
	

}
