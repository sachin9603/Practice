package june21.abstracttt;

public interface DemoInterface {
	

}
