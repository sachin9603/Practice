package Com.Anudip.hibernate6879Student;

public enum Type_OF_address {

	home , //0
	office, //1
	current //2
	
	
}
