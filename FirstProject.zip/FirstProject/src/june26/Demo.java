package june26;

import java.util.ArrayList;


public class Demo {
	
	// This is main method 
	public static void disply() {
		System.out.println("yes it working ");
	}
	
    public static void main(String[] args) {
		
        //syso+crtl+space
    	
    /*	System.out.println("kuchBhi"); 
    	
    	System.out.println("SomeThingElse");  */
    	
    	int sachinAge  = 20  ;  // variable , method
    	// camel case    --- jismeFirstWordSmall
    	// pascal case   ---- VoHoteHaiAllCapse
    	
    	Demo.disply();
    	
    	// 
    	int c  = 20  ;
    	short b  = 10  ;
    	long u  = 30  ;
    	byte bb  =20  ;
    	boolean vvv  = true  ;
    	
    	String s  = "Vivek";
    	
    	String adhar  = "437387384734" ;
    	
    
    	int a=5;
    	
    	System.out.println((--a+--a)*(++a-a--)+(--a+a--)*(++a+a++));
    	
//    	: Wrapper Classes
//    	byte : java.lang.Byte
//    	short : java.lang.Short
//    	int : java.lang.Integer
//    	long : java.lang.Long
//    	float : java.lang.Float
//    	double : java.lang.Double
//    	char : java.lang.Character
//    	boolean : java.lang.Boolean	
    	
    	
    	int hh  = 30 ;
    	
    	
    	Integer hhh  = 30  ;
    	String sss = hhh.toString();
    	
    	
    	boolean gg  = true  ;
    	Boolean ggg  = true ;
    	
    	///ArrayList<Student>  gj  = new ArrayList<>() ;
    	
    	
    	
    	
    	
    	}
}
