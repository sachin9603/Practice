/**
 * 
 */
/**
 * 
 */
module Jdbc9284 {
	requires java.sql;
}