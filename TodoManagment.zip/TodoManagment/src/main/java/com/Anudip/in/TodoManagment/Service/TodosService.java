package com.Anudip.in.TodoManagment.Service;

import java.util.List;

public interface TodosService {
	
	public List<String> retriveToDosList(String user);

}
