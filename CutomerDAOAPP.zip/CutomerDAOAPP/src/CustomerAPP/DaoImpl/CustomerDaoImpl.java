package CustomerAPP.DaoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import CustomerAPP.Dao.CustomerDao;
import CustomerAPP.Exception.CustomerException;
import CustomerAPP.model.Customer;
import CustomerAPP.util.Dao;
import CustomerAPP.util.QueryUtil;

public class CustomerDaoImpl implements CustomerDao {

	@Override
	public String registerCustomer(Customer cus) throws CustomerException {
		// TODO Auto-generated method stub
		
		String  msg  = "data is not inserted " ;
		
		try(Connection con  = Dao.provideConnection()) {
		//	String query   = "insert into customer(cName, cPassword, address) values (?,?,?)" ;
			PreparedStatement ps  = con.prepareStatement(QueryUtil.registerCus()) ;
			ps.setString(1,cus.getCName() );
			ps.setString(2,cus.getCPassword() );
			ps.setString(3,cus.getAddress() );
			
		int row  =	ps.executeUpdate() ;
		
		if (row >0) {
			msg = " You have been registered" ;
			
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return msg;
	}

	@Override
	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer updateCustomer(Customer cus, int C_id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteCustomer(int c_id) {
		// TODO Auto-generated method stub
		
	}

}
