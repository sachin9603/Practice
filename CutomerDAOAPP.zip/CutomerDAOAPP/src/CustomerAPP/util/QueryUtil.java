
package CustomerAPP.util;

public class QueryUtil {
	
	public static String registerCus() {
		return "insert into customer(cName, cPassword, address) values (?,?,?)" ;
	}

}
