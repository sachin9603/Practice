package CustomerAPP.Usecase;

import java.util.Scanner;

import CustomerAPP.Dao.CustomerDao;
import CustomerAPP.DaoImpl.CustomerDaoImpl;
import CustomerAPP.Exception.CustomerException;
import CustomerAPP.model.Customer;

public class CustomerStuff {
	
	public static CustomerDao  dao   = new CustomerDaoImpl() ; 
	
	public static Scanner sc  = new Scanner(System.in) ;
	
	public static void main(String[] args) {
		
		
		while(true) {
			System.out.println("Enter your choice "); 
			
			System.out.println("1 for inserting data ");
			System.out.println("2 for update data ");
			System.out.println("3 for delete  data ");
			System.out.println("4 for get all Customer data ");
			System.out.println("5  for  exit ");
			
			int cusChoice  = sc.nextInt() ;
			
			switch(cusChoice) {
			case 1 :
				System.out.println("Enter your name");
				String name  = sc.next() ;
				
				System.out.println("Enter your password");
				String password   = sc.next() ;
				
				System.out.println("Enter your address");
				String address  = sc.next() ;
				
				Customer c1  = new Customer(name , password  , address) ; 
				
				try {
					String msggg  = dao.registerCustomer(c1);
					System.out.println(msggg);
				} catch (CustomerException e) {
					// TODO Auto-generated catch block 
					}
				break ;
			case 5 :
			System.out.println("Thank you for visit");
			return  ;
			
			default :
				System.out.println(" kindly choose right option ");
		}
	}
	

}
}
