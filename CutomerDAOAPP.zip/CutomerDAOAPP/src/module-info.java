/**
 * 
 */
/**
 * 
 */
module CutomerDAOAPP {
	requires java.sql;
}