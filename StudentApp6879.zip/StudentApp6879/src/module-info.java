/**
 * 
 */
/**
 * 
 */
module StudentApp6879 {
	requires java.sql;
}