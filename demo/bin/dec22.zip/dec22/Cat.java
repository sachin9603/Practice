package dec22;

public class Cat extends Animal  {
	 // code reusability 
	//    reusability 
	@Override
	void voice() {
		System.out.println("meow meow .... ");
	}

}
