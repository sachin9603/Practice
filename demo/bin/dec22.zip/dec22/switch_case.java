package dec22;

public class switch_case {

	
	public static void main(String[] args) {
		
		
		int day  = 6567  ;
		
		switch(day) {
		
		case 1 :
			System.out.println("monday");
			break ;
		case 2 :
			System.out.println("tuesday");
			break ;
		case 3 :
			System.out.println("wednesday");
			break ;
		case 4 :
			System.out.println("thrusday");
			break ;
			default :
				System.out.println("kuch bhi ");
		}
		
	}
}
