package dec22;

public class BOI extends Bank {

	@Override
	int rateOfIntrest() {
		// TODO Auto-generated method stub
		return 5;
	}

}
