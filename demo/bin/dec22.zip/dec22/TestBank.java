package dec22;

public class TestBank {
	
	public static void main(String[] args)
	{
		//instance 
	//	Bank b  = new Bank() ;
		
		//constructor
		
		SBI a = new SBI();// yaha par default const
		
		// that constructor which have made into bank 
		
		
		
//	int aa= a.rateOfIntrest() ;
//		System.out.println(aa);
//		
//		a.member = 50 ;
//		
//		System.out.println(a.member) ;
//		
//		a.run();
//	
//		SBI.HomeLone();
//		
//		Bank.HomeLone();
//		
//		
		
//		
//		int rateOfIntrest  = a.rateOfIntrest() ;
//		System.out.println(rateOfIntrest);
		
		Bank.HomeLone();
		a.run();
		
		
	}

}
