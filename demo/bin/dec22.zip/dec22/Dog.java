package dec22;

public class Dog extends Animal   {

	@Override
	void voice() {
		System.out.println(" bark bark ...");
	}
}
