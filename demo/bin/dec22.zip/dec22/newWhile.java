package dec22;

public class newWhile {

	public static void main(String[] args) {
		
		int a  = 10 ;
		// 100 percent 1 baar chalega 
		
		
		for (int  i =0  ;i<=5  ; i++) {
			System.out.print(i);
			if(i == 3)
			{
			 break ;	
			}
			 
			
		}
		return ;
		
	}
}
