package dec26;

public class Poly { 
	public static void main(String[] args) {
		  
		
	 // polymorphism  ----  multiple + form 
		// runtime poly---- is a relation 
		// compiletime poly ----same class ander hoga 
		
	}

}
