package dec29;

public class QualityAnalyst implements Employee {

	@Override
	public void saveEmployee() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void findEmployee() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteEmployee() {
		// TODO Auto-generated method stub
		
	}
	
	void getAll() {
		Employee.getAllEmployee();
	}

	
}
