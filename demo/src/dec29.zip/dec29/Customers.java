package dec29;

public interface Customers {

	/// multiple inheriatace kese achive kare 
	
	// do class ko ek class inherit kar rahi hai 
	
	void saveCustomer();
	
	
}
