package dec29;

public class Demo {
	
	public static void main(String[] args) {
		
	}

}
