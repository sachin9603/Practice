package dec29;

public class Sachin {
	int number  = 500 ;
	

}
