package dec29;

public class Guard implements Employee {

	@Override
	public void saveEmployee() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void findEmployee() {
		// TODO Auto-generated method stub
		
	}

	
	
	void check() {
		System.out.println("every thing is fine ");
	}

	@Override
	public void deleteEmployee() {
		// TODO Auto-generated method stub
		
	}

}
